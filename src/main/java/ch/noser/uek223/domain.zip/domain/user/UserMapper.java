package ch.noser.uek223.domain.user;

import ch.noser.uek223.domain.user.dto.UserDTOSupplier;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper {
    UserDTOSupplier userToUserDTOCustomer(User user);
}
