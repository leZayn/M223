package ch.noser.uek223.domain.product;

import ch.noser.uek223.domain.product.dto.ProductDTOSupplier;
import ch.noser.uek223.domain.product.dto.ProductDTOCustomer;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ProductMapper {
    ProductDTOSupplier productToProductDTOSupplier(Product product);
    //ProductDTOCustomer productToProductDTOCustomer (Product product);

}
