package ch.noser.uek223.domain.product;

public enum Availability {
    AVAILABLE,
    ARCHIVED,
    OUT_OF_STOCK
}
