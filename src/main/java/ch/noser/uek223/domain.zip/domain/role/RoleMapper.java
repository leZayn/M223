package ch.noser.uek223.domain.role;

import ch.noser.uek223.domain.role.dto.RoleDTOSupplier;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface RoleMapper {
    RoleDTOSupplier roleToRoleDTOCustomer(Role role);
}
